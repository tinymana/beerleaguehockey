# Batch 12.06 — Bench disappointment
Use matching roster variant and side from Batch 12.04. Trigger once after a conceded goal, stagger starts per player, use manifest frame durations, then restore standing idle. Preserve anchor (8,8), nearest-neighbor filtering and roster palette. No gameplay or collision changes. Poses and timing are provisional. Preview is not a runtime texture.
