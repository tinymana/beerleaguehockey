# Batch 11.03 — North goal scored
Use composite OR net, bottle and puck layers. Align mouth (24,28) with existing goal line. Puck anchor (24,22) is illustrative; hide the live puck only if using the scored composite. Do not duplicate the puck or change scoring physics. Use nearest-neighbor scaling. Bottle remains unchanged from 11.01. Preview is not a runtime asset.
