# Batch 15.01 — Locker room environment
Use nearest-neighbor integer scaling. Atlas modules are 16×32, split into 8×8 tiles. Draw floor before walls and furnishings. Preview is illustrative, not a collision map. Wall corners and camera projection are provisional; verify seams in the scene. Keep lockers, benches, characters and gameplay logic separate. No collision changes authorized.
