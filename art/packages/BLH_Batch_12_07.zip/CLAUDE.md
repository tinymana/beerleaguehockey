# Batch 12.07 — Penalty box
Use either orientation, or two modules on the same rink side. Align board contact to rink edge. Render floor and seating, players at anchors, then enclosure and glass. Alternatively use composite for empty box. Closed door is static; animated doors are Batch 12.09. Nearest-neighbor filtering. No changes to penalty rules or collisions. Placement and spacing provisional.
