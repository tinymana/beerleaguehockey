# Batch 10.14 — Glass damage
Use the same anchors and layer as 10.09. Swap intact, cracked, shattered (dense crack pattern), or missing (transparent) textures by panel ID. Keep support posts separate. Use nearest-neighbor scaling. Damage triggers and reset timing are gameplay decisions; do not change collision or physics. Missing panels are visual only. Preview is not a game texture.
