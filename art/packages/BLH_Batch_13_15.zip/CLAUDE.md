# Batch 13.15 — Goal lights
Use frame zero when idle. On confirmed goal, play frames 1–7 in a loop for three seconds, then reset to zero. Mount outside protective glass behind each net; anchor [8,14]. Nearest-neighbor rendering. Siren is visual only; connect existing audio event separately. No scoring or collision changes. Placement and timing provisional.
