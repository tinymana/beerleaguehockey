# Batch 15.06 — Team celebrations
Use manifest frame rectangles, nearest-neighbor rendering and foot anchor [16,30]. Trigger after a locker room victory; stagger actors. High-five is a single-player gesture: pair with a mirrored teammate and align hands in scene. Return to idle after 740 ms. No gameplay or reward changes. Placement and timing provisional.
