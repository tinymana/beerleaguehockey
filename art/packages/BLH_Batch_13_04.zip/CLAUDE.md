# Batch 13.04 — Seated spectators
Place at Batch 13.01 seatAnchorsLocal with sprite anchor (8,8). Select side by seating location; use stable seeded variant selection and occupancy. Render above seating and below foreground railings. Keep variant IDs for future reactions. Nearest-neighbor filtering. Static seated poses only; no gameplay changes. Verify fit and visual scale in Arena Asset Lab.
