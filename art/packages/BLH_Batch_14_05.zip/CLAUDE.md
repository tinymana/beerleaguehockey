# Batch 14.05 — Arena signage
Load manifest.json and use individual PNGs or atlas rectangles. Mount at anchorLocal on arena walls outside the ice. Use nearest-neighbor integer scaling. Do not mirror lettering. Blank sign supports custom bitmap text. Signs are decorative; do not alter collision or routing. Verify readability and placement in Arena Asset Lab.
