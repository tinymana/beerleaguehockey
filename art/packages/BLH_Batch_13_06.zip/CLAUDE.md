# Batch 13.06 — Cheering spectators
Match side and variant to 13.05. Use anchor [8,8], nearest-neighbor filtering. Play the four frames for 500ms per loop, stagger starts per fan, then restore standing or seated pose after the reaction window. Render behind railings. No gameplay or attendance changes. Arm poses and timing are provisional; test clipping in the arena.
