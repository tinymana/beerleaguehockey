# Batch 11.04 — South scored goal
Use the same mouth and post anchors as 11.02. Render net, puck, then bottle, or use the composite instead. Do not render a second puck over the scored sprite. Use nearest-neighbor filtering. Puck position is illustrative; actual scoring and collision remain unchanged. Preview is not a runtime asset.
