# 15.05 Locker room beer animations
Use manifest frame durations and nearest-neighbor scaling. Seated pose requires separate bench; anchor is provisional. Play once then return to idle. Frame 1 can serve as a static toast pose. Blue/red reuse 15.04 character proportions. Cosmetic adult NPC animation only; no gameplay effects. Validate in game.
