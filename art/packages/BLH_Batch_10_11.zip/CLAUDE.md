# Batch 10.11 — Yellow kickplates

Consolidated exact kickplate layers from batches 10.01–10.08. Use manifest atlasRect and offset relative to the corresponding board module. Render with nearest-neighbor filtering. Straight pieces repeat along their original board axis; corners are single modules. Use either the complete board module or the separate body plus kickplate, never both. Preserve existing collision geometry. Preview is not a production texture. Validate seams in Arena Asset Lab.
