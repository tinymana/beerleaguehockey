# Batch 13.05 — Standing spectators
Match side and variant to Batch 13.04. Keep anchor [8,8], use nearest-neighbor filtering. Standing poses are provisional silhouette extensions of seated sprites; review visual distinction and spacing in Arena Asset Lab. No gameplay or collision changes.
