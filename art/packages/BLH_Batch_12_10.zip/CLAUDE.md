# Batch 12.10 — Bench equipment
Use individual sprites or atlas rectangles, nearest-neighbor filtering. Place on bench floor behind players where appropriate; avoid gate clearance and seat anchors. East variants mirror west. Decorative only; no collision or gameplay changes. Dimensions and placement are provisional. Preview is not a runtime texture.
