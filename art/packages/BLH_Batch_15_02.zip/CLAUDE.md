# Batch 15.02 — Player lockers
Use individual sprites or atlas regions, nearest-neighbor sampling. Anchor at floor contact [16,30]. Closed/open/jersey are static interchangeable states. Four baked color variants. Place above floor and sort by floor anchor. Footprints and collision remain provisional; no gameplay changes. Preview is not a runtime asset.
