# Batch 12.05 — Bench celebrations
Use manifest atlas rectangles and durations. Select matching standing variant and side. Keep anchor (8,8). On goal, stagger starts per player, loop for roughly 1–2 seconds, then restore standing or seated state. Use nearest-neighbor filtering. No gameplay or collision changes. Timing and poses provisional. Preview is not a runtime texture.
