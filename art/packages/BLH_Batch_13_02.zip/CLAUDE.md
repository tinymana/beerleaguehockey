# Batch 13.02 — Stairs and aisles
Use the 64×32 modules between seating sections. Select east or west orientation. Render with nearest-neighbor filtering. Path anchors are suggested visual waypoints, not navigation or collision rules. Verify alignment with Batch 13.01 in the Arena Asset Lab. Preview is not a runtime texture.
