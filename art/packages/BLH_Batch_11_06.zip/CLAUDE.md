# BLH 11.06 — South bottle knockoff
Use manifest.json and nearest-neighbor sampling. Place frame at original goal top-left minus (8,0). Play once on confirmed bottle impact, hold final frame until reset. Use composite atlas OR padded stationary net plus bottle atlas, never both. No changes to collision or scoring. Verify trajectory, bottle rotation and clearance in Arena Asset Lab.
