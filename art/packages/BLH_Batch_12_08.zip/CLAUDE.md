# Batch 12.08 — Timekeeper booth
Place beside penalty boxes using boardContactLocalX. Use composite OR layers in manifest order (floor, seating, desk, enclosure, glass); insert officials before enclosure/glass. Nearest-neighbor filtering. Console is decorative; no timer logic or collision changes. Placement, anchors and dimensions provisional. Preview not a runtime texture.
