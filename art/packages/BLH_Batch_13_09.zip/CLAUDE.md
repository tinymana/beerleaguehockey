# Batch 13.09 — Heckling spectators
Match side and variant to existing spectator IDs. Use 16x16 frames, anchor [8,8], nearest-neighbor scaling. Play once or repeat twice on disputed calls, stagger starts, then restore idle. Keep behind railings. No gameplay or penalty changes. Gestures and timing provisional; verify in Arena Asset Lab.
