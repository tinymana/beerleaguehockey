# Beer League Hockey — 09.01
Copy ice/ into the project asset directory. Atlas is 32×32, 8×8 cells, no spacing or margin. Use nearest-neighbor filtering and integer scaling. IDs 0–3 base, 4–7 scuff, 8–11 transparent reflection overlays, 12–15 snow. Use one base variant per continuous region to avoid phase seams. Reflections use separate overlay layer; scuff and snow are opaque replacement tiles.

Phaser: preload with `this.load.image('ice09', 'assets/ice/ice_tileset_4x4.png')`; create tilemap with tileWidth:8, tileHeight:8; use `map.addTilesetImage('ice09','ice09',8,8,0,0)` and a blank layer. Keep rink markings, boards, nets and collision geometry separate. Vertical overhead camera only. Do not use preview as gameplay texture.

Base tiles reconstructed as periodic patterns using colors sampled from generated artwork; other tiles downsampled from artwork. Scuff/snow seams and in-engine appearance require review. Extra variants are provisional previews of 09.02/09.03, not approved batches.
