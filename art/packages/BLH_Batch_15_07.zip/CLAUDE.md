# Batch 15.07 — Frustrated players
Use manifest sequences with nearest-neighbor scaling. Anchor at feet [16,29]. Play once after a disappointing result, stagger NPC reactions, then restore idle. No gameplay or morale changes implied. Provisional timing and placement; test in locker room. Preview is not a game texture.
