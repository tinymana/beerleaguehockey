# Batch 15.03 — Locker room furniture
Use RGBA sprites or reconstruct from 8x8 tiles, not both. Nearest-neighbor scaling. Place on furniture layer above floor; use anchorLocal for sorting. Anchors and collision footprints are provisional; small equipment is decorative. No gameplay changes. Preview is not a game asset.
