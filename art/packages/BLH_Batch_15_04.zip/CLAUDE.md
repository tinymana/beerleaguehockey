# 15.04 Players dressing
Use manifest sequences, nearest-neighbor scaling, bottom-center anchor. Play at 160 ms/frame; repeat preparation actions as needed, then return to ready. Blue/red are provisional palette variants, not full appearance customization. Tie-skates pose requires separate bench. No gameplay changes. Validate placement and animation in game.
