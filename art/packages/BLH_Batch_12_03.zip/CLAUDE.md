# Batch 12.03 — Seated players
Use 16x16 frames from seated_atlas.png. Place center (8,8) on seatAnchorsLocal from 12.01 or 12.02. Render over floor and seating, under enclosure where needed. Six variants per side; choose by roster, palette swap jersey colors for other teams. Nearest-neighbor, no physics changes. Static poses and spacing provisional. Preview is not a runtime texture.
