# Batch 15.09 — Tactics whiteboard
Use manifest IDs and atlas rectangles. Place at bottom-center anchor; nearest-neighbor filtering. Use blank board for dynamic tactical overlays. Diagrams are illustrative, not authoritative AI tactics. Static variants; no gameplay or collision changes. Verify scale and placement in locker room. Preview is not a game texture.
