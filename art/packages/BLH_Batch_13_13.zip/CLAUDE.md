# Batch 13.13 — Arena tunnels
Place at breaks in seating, align aisleAnchorLocal to aisle center. Route departing spectators toward exitAnchorLocal only when open; hide at exit using game logic. Closed state is a static visual variant. Use nearest-neighbor filtering. Footprint and routing anchors are provisional; verify in Arena Asset Lab. No gameplay or collision changes.
