# Batch 13.14 — Arena structure
Use individual PNGs or atlas rectangles. Nearest-neighbor filtering. Straight beams repeat along their axis; junctions and columns are single modules. Place outside playable ice and avoid spectator paths. Decorative only; no collision changes. Dimensions and placement provisional until Arena Asset Lab review.
