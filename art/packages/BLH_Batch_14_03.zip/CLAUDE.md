# Batch 14.03 — Championship banners
Use achievement key to select banner from actual dynasty records. Mount at anchorLocal on arena wall or rafters outside playable ice. Render year in yearLabelRect using small bitmap text. Blank variant supports custom awards. Never invent championship records. Use nearest-neighbor rendering; no collision changes. Palette, size and placement provisional.
