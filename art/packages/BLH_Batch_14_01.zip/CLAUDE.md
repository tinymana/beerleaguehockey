# Batch 14.01 — Ice resurfacer
Use directional sprites with center anchor [24,24], nearest-neighbor rendering. Move along scripted intermission paths; rotate the separate trail to match travel direction and render below vehicle. Three palette variants. Static directional sprites, not wheel animations. Do not modify live gameplay or collision. Scale, trail opacity and path clearance provisional.
