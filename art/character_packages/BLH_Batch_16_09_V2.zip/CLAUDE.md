# Batch 16.09 v2
Use manifest IDs to map to existing attributes; do not create mechanics or change saves. Replace previous artwork only after checking mappings. These are cropped framed cards with baked labels and backgrounds, not transparent glyphs. Compact labels may be hard to read; use accessible UI text. Render at integer scale.
