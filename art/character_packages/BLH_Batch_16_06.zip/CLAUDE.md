# Body type references
These are concept crops only, with backgrounds, heads and branded jerseys baked in. Do not use as modular sprites. Use silhouettes as references for unbranded body layers; separate heads, equipment and masks before integration. Build labels are cosmetic, not stat modifiers.
