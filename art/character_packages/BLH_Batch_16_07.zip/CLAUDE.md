# Batch 16.07
56 reference thumbnails, 64x64. Use for equipment selection previews only. Backgrounds and some brand marks are baked in; redraw unbranded transparent directional overlays and establish attachment anchors before equipping on player models. Do not change gameplay attributes or existing sprites.
