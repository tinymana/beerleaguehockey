# Batch 16.04
35 visible reference crops, numbered sequentially because source labels skip numbers. Do not treat these as transparent beard overlays. Separate facial hair and validate anchors before enabling modular customization. No gameplay changes.
