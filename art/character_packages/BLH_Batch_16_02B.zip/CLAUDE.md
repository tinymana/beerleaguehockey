# Batch 16.02B — Bald portrait presets

Add alongside 16.02 Revised. Use stable IDs bald_01 through bald_32, nearest-neighbor rendering, and atlas rectangles in manifest.json. These are cropped concept portraits with opaque backgrounds, baked jerseys and some baked facial hair. They are NOT clean modular head layers. Do not overlay interchangeable hair or beards until clean, consistently aligned head assets and masks are available. Cropping and resizing may affect proportions; review in game. No appearance-based gameplay attributes.
